/**
 * Author: Jessica Wang
 * Andrew iD: xiaotonw
 */
package com.example.project4task2;

import android.app.Activity;
import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetGIF {
    private MainActivity mainActivity;
    private String searchTerm;

    //search method that invokes background activity
    public void search(String searchTerm, Activity activity, MainActivity mainActivity) {
        this.mainActivity = mainActivity;
        this.searchTerm = searchTerm;
        new BackgroundTask(activity).execute();
    }

    private class BackgroundTask {
        private final Activity activity;

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        public void execute() {
            new Thread(() -> {
                String gifUrl = search(searchTerm);
                activity.runOnUiThread(() -> mainActivity.gifReady(gifUrl));
            }).start();
        }

        //connect to the webService, pass the search term to the app, and return the url
        private String search(String searchTerm) {
            String gifURL = null;
            String webServiceUrl = "http://10.0.2.2:8080/Project4Task2-1.0-SNAPSHOT/fetchGif?query="+searchTerm;

            try {
                URL url = new URL(webServiceUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                // Set a timeout for establishing the connection
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                // Get the response code from the web service
                int responseCode = connection.getResponseCode();
                // Check if the response is HTTP OK (200)
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    // Read each line from the response and append it to the StringBuilder
                    while ((line = in.readLine()) != null) {
                        response.append(line);
                    }
                    in.close();

                    // Log the complete response for debugging purposes
                    Log.d("GetGIF", "Response from Web Service: " + response);

                    gifURL = response.toString().trim();

                } else {
                    // Log an error message if the response code is not HTTP OK
                    Log.e("GetGIF", "Failed to fetch GIF. Response Code: " + responseCode);
                }
            } catch (Exception e) {
                // Log any exceptions encountered during the process
                Log.e("GetGIF", "Error fetching data from Web Service: " + e.getMessage());
                e.printStackTrace();
            }

            return gifURL;
        }
    }
}
