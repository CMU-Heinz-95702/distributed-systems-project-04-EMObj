/**
 * Author: Jessica Wang
 * Andrew iD: xiaotonw
 * Description: MainActivity handles user interactions, including taking a search term input,
 * fetching GIF URLs through a separate class (`GetGIF`), and displaying the GIFs using `GifImageView`.
 */

package com.example.project4task2;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import pl.droidsonroids.gif.GifDrawable;
import pl.droidsonroids.gif.GifImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);

        // Initializing UI components
        Button submitButton = findViewById(R.id.submitButton);
        EditText searchTermEditText = findViewById(R.id.searchTerm);
        TextView feedbackTextView = findViewById(R.id.feedbackTextView);

        // Setting click listener
        submitButton.setOnClickListener(view -> {
            String searchTerm = searchTermEditText.getText().toString().trim();
            if (!searchTerm.isEmpty()) {
                feedbackTextView.setVisibility(View.GONE);
                GetGIF gg = new GetGIF();
                gg.search(searchTerm, MainActivity.this, MainActivity.this);
            } else {
                feedbackTextView.setText("Please enter a search term.");
                feedbackTextView.setVisibility(View.VISIBLE);
            }
        });
    }

    public void gifReady(String gifUrl) {
        GifImageView gifImageView = findViewById(R.id.gifImageView);
        TextView feedbackTextView = findViewById(R.id.feedbackTextView);
        EditText searchTermEditText = findViewById(R.id.searchTerm);

        if (gifUrl != null && !gifUrl.isEmpty()) {
            new Thread(() -> {
                try {
                    // Download the GIF to a temporary file
                    File gifFile = downloadGifToFile(gifUrl);

                    // Create a GifDrawable from the file
                    GifDrawable gifDrawable = new GifDrawable(gifFile);

                    // Update the UI on the main thread
                    runOnUiThread(() -> {
                        gifImageView.setImageDrawable(gifDrawable);
                        feedbackTextView.setText("GIF Found!");
                        feedbackTextView.setVisibility(View.VISIBLE);
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                    runOnUiThread(() -> {
                        // Handling errors and updating feedback to the user
                        feedbackTextView.setText("Error loading GIF. Please try again.");
                        feedbackTextView.setVisibility(View.VISIBLE);
                    });
                }
            }).start();
        } else {
            runOnUiThread(() -> {
                // Providing feedback if no GIF URL was found
                gifImageView.setImageResource(R.mipmap.ic_launcher); // Fallback image
                feedbackTextView.setText("Sorry, couldn't find a GIF");
                feedbackTextView.setVisibility(View.VISIBLE);
            });
        }

        runOnUiThread(() -> searchTermEditText.setText("")); // Clear input field
    }

    /**
     * Downloads a GIF from the given URL and saves it to a temporary file.
     */
    private File downloadGifToFile(String gifUrl) throws IOException {
        // Create a temporary file
        File tempFile = File.createTempFile("temp_gif", ".gif", getCacheDir());
        tempFile.deleteOnExit();

        // Download the GIF and write to the file
        try (InputStream inputStream = new URL(gifUrl).openStream();
             FileOutputStream outputStream = new FileOutputStream(tempFile)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }

        return tempFile;
    }


}
