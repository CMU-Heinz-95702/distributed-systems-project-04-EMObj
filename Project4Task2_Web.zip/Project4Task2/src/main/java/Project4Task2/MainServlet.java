/**
 * Author: Jessica Wang
 * Andrew iD: xiaotonw
 */

package Project4Task2;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Random;

@WebServlet("/fetchGif")
public class MainServlet extends HttpServlet {


    private static final String MONGO_CONNECTION_STRING = "mongodb+srv://xiaotonw:Wang0019@cluster0.yzxb6.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
    private static final String MONGO_DATABASE_NAME = "Project4Task2";
    private static final String MONGO_COLLECTION_NAME = "logs";

    private static final String API = "AIzaSyBro3UFxoa8G5WUFnzS-x7T5XCc4CMXK7o";

    private MongoCollection<Document> logCollection;

    @Override
    public void init() throws ServletException {
        super.init();
        MongoClient mongoClient = MongoClients.create(MONGO_CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(MONGO_DATABASE_NAME);
        logCollection = database.getCollection(MONGO_COLLECTION_NAME);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
        String searchTerm = req.getParameter("query");

        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.setContentType("application/json");
            try {
                resp.getWriter().write("{\"error\": \"Query parameter is missing.\"}");
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        try {
            // Log request metadata
            Document log = new Document();
            log.append("timestamp", System.currentTimeMillis())
                    .append("search_term", searchTerm)
                    .append("user_agent", req.getHeader("User-Agent"));

            // Build the API URL
            String apiUrl = "https://tenor.googleapis.com/v2/search?q="
                    + searchTerm + "&key=" + API + "&client_key=my_test_app";

            log.append("api_request_time", System.currentTimeMillis());

            // Fetch GIF data from the API
            long startTime = System.currentTimeMillis();

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            int responseCode = connection.getResponseCode();

            long endTime = System.currentTimeMillis();
            log.append("api_response_time", endTime - startTime);

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String response = "";
                response = fetch(apiUrl);
                Gson gson = new Gson();
                JsonObject jsonObject = gson.fromJson(response, JsonObject.class);
                // Get the 'results' array from the JSON data
                JsonArray resultsArray = jsonObject.getAsJsonArray("results");
                Random random = new Random();
                int randomIndex = random.nextInt(resultsArray.size());
                JsonObject randomGifObject = resultsArray.get(randomIndex).getAsJsonObject();

                String gifResponse = randomGifObject.getAsJsonObject("media_formats")
                        .getAsJsonObject("gif")
                        .get("url").getAsString();
                in.close();

                // Log success response
                log.append("response_status", "success")
                        .append("response_data", gifResponse)
                        .append("response_time", System.currentTimeMillis());

                logCollection.insertOne(log);

                // Send response to Android app
                resp.setContentType("application/json");
                resp.setStatus(HttpServletResponse.SC_OK);
                resp.getWriter().write(gifResponse);
            } else {
                log.append("response_status", "error")
                        .append("error_message", "Failed to fetch GIF data.");

                logCollection.insertOne(log);

                resp.setContentType("application/json");
                resp.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
                resp.getWriter().write("{\"error\": \"Failed to fetch GIF data.\"}");
            }
        } catch (Exception e) {
            Document errorLog = new Document();
            errorLog.append("timestamp", System.currentTimeMillis())
                    .append("search_term", searchTerm)
                    .append("error", e.getMessage());

            logCollection.insertOne(errorLog);

            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.setContentType("application/json");
            try {
                resp.getWriter().write("{\"error\": \"Server error occurred.\"}");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }



        private static String fetch(String urlString) {
            String response = "";
            try{
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String str;
                // Read each line of "in" until done, adding each to "response"
                while ((str = in.readLine()) != null) {
                    // str is one line of text readLine() strips newline characters
                    response += str;
                }
                in.close();
            } catch (IOException e) {
                System.out.println("Eeek, an exception");

            }
            return response;
        }

}
