/**
 * Author: Jessica Wang
 * Andrew iD: xiaotonw
 */
package Project4Task2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    private static final String MONGO_CONNECTION_STRING = "mongodb+srv://xiaotonw:Wang0019@cluster0.yzxb6.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
    private static final String MONGO_DATABASE_NAME = "Project4Task2";
    private static final String MONGO_COLLECTION_NAME = "logs";

    private MongoCollection<Document> logCollection;

    @Override
    public void init() throws ServletException {
        super.init();
        MongoClient mongoClient = MongoClients.create(MONGO_CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(MONGO_DATABASE_NAME);
        logCollection = database.getCollection(MONGO_COLLECTION_NAME);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.println("<html><head><title>Dashboard</title></head><body>");
        out.println("<h1>Web Service Dashboard</h1>");

        // Operations Analytics
        out.println("<h2>Analytics</h2>");

        Map<String, Integer> searchCount = new HashMap<>();
        int totalRequests = 0;
        long totalResponseTime = 0;

        for (Document log : logCollection.find()) {
            String term = log.getString("search_term");
            searchCount.put(term, searchCount.getOrDefault(term, 0) + 1);

            if (log.containsKey("api_response_time")) {
                totalResponseTime += log.getLong("api_response_time");
            }
            totalRequests++;
        }

        double avgResponseTime = totalRequests > 0 ? (double) totalResponseTime / totalRequests : 0;

        out.println("<p><strong>Total Requests:</strong> " + totalRequests + "</p>");
        out.println("<p><strong>Average API Response Time:</strong> " + avgResponseTime + " ms</p>");
        out.println("<p><strong>Top Search Terms:</strong> " + searchCount + "</p>");

        // Display Logs
        out.println("<h2>Logs</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>Timestamp</th><th>Search Term</th><th>User Agent</th><th>API Response Time</th><th>Response Data</th></tr>");

        for (Document log : logCollection.find()) {
            out.println("<tr>");
            out.println("<td>" + log.get("timestamp") + "</td>");
            out.println("<td>" + log.get("search_term") + "</td>");
            out.println("<td>" + log.get("user_agent") + "</td>");
            out.println("<td>" + log.get("api_response_time") + " ms</td>");
            out.println("<td>" + log.get("response_data") + "</td>");
            out.println("</tr>");
        }

        out.println("</table></body></html>");
    }
}
